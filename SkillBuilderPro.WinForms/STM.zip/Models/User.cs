using System;

namespace SportsTrainingManager.Models
{
    /// <summary>
    /// User.cs - Represents a user account in the system
    /// This class stores all user information including profile data and authentication details
    /// Time Complexity: O(1) for all operations (simple property access)
    /// Space Complexity: O(1) - fixed size properties
    /// </summary>
    public class User
    {
        // ===== UNIQUE IDENTIFIERS =====
        /// <summary>
        /// Unique identifier for each user (GUID = Globally Unique ID)
        /// Used to distinguish one user from another in the database
        /// </summary>
        public Guid Id { get; set; }

        // ===== LOGIN CREDENTIALS =====
        /// <summary>
        /// Username that user enters to log in (must be unique)
        /// Minimum 3 characters required
        /// </summary>
        public string Username { get; set; }

        /// <summary>
        /// Password for user account (stored as hashed value for security)
        /// Never stored in plain text in production
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// User's email address for recovery and notifications
        /// Must be in valid email format (contains @)
        /// </summary>
        public string Email { get; set; }

        // ===== PROFILE INFORMATION =====
        /// <summary>
        /// User's full name (First Name + Last Name)
        /// Displayed throughout the application
        /// </summary>
        public string FullName { get; set; }

        /// <summary>
        /// User's phone number (optional, for contact purposes)
        /// Stored as string to preserve formatting
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// User's role in the system
        /// Can be: Parent, Coach, or Athlete
        /// Determines what features they can access
        /// </summary>
        public UserRole Role { get; set; }

        // ===== SPORT & TRAINING PREFERENCES =====
        /// <summary>
        /// The sport user wants to train in
        /// Examples: Soccer, Basketball, Baseball, Tennis, etc.
        /// </summary>
        public string Sport { get; set; }

        /// <summary>
        /// Specific area of training user wants to focus on
        /// Examples: Shooting, Defense, Speed, Strength, All-Around
        /// Helps customize training drills and schedules
        /// </summary>
        public string TargetArea { get; set; }

        /// <summary>
        /// User's current experience level with their sport
        /// 1 = Beginner (just starting)
        /// 2 = Intermediate (some experience)
        /// 3 = Advanced (competitive level)
        /// Used to recommend appropriate difficulty drills
        /// </summary>
        public int ExperienceLevel { get; set; }

        // ===== ACCOUNT TRACKING =====
        /// <summary>
        /// Date and time when user account was created
        /// Useful for understanding how long user has been with us
        /// </summary>
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Date and time of user's most recent login
        /// Helps track active users and user engagement
        /// </summary>
        public DateTime LastLogin { get; set; }

        /// <summary>
        /// Whether the account is active (true) or deactivated (false)
        /// Allows users to disable their account without deleting it
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Constructor - Initializes a new User with default values
        /// Time Complexity: O(1)
        /// Space Complexity: O(1)
        /// </summary>
        public User()
        {
            // Generate unique ID for this user
            Id = Guid.NewGuid();
            
            // Set creation date to current time
            DateCreated = DateTime.Now;
            
            // Set first login to current time
            LastLogin = DateTime.Now;
            
            // Account is active by default when created
            IsActive = true;
        }

        /// <summary>
        /// Returns formatted string representation of the user
        /// Useful for displaying user info in menus or lists
        /// Time Complexity: O(1)
        /// Space Complexity: O(1)
        /// </summary>
        public override string ToString()
        {
            // Return user info in readable format
            return $"{FullName} ({Role}) - {Sport}/{TargetArea}";
        }
    }

    /// <summary>
    /// UserRole - Enumeration of possible user roles
    /// Enum = a set of named constants representing fixed options
    /// Each user must have exactly one of these roles
    /// </summary>
    public enum UserRole
    {
        /// <summary>Parent or guardian managing a young athlete's training</summary>
        Parent,

        /// <summary>Coach or trainer providing guidance and instruction</summary>
        Coach,

        /// <summary>Athlete training to improve their sport performance</summary>
        Athlete
    }
}
