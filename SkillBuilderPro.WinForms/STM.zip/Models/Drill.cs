using System;

namespace SportsTrainingManager.Models
{
    /// <summary>
    /// Drill.cs - Represents a single training drill or exercise
    ///
    /// A drill is an individual exercise that gets added to a training session.
    /// Example: "Agility Ladder" - Speed drill - 20 minutes - Medium difficulty
    ///
    /// Properties:
    /// - Id, CreatedBy        - identify the drill and who made it
    /// - Name, Description    - describe what the drill is
    /// - Category, SkillCategory - what type of drill it is (Speed, Strength, etc.)
    /// - Duration             - how long the drill takes in minutes
    /// - Difficulty           - how hard the drill is (1=Easy, 2=Medium, 3=Hard)
    /// - Sport                - which sport this drill is designed for
    /// - TargetArea           - what skill area the drill improves
    /// - Sets, Reps           - how many sets and reps to perform
    /// - EquipmentNeeded      - what gear is required
    /// - IsActive             - whether the drill is available to use
    ///
    /// Methods:
    /// - GetDifficultyLabel()  - converts 1/2/3 to Easy/Medium/Hard
    /// - GetCategoryLabel()    - returns a readable category description
    /// - GetTotalTime()        - calculates total time including all sets
    /// - GetSummary()          - returns a one line summary of the drill
    /// - Deactivate()          - marks the drill as inactive
    /// - Activate()            - marks the drill as active again
    ///
    /// TIME COMPLEXITY: O(1) for all operations
    /// SPACE COMPLEXITY: O(1) - fixed size properties
    /// </summary>
    public class Drill
    {
        // ═══════════════════════════════════════════════════
        // PROPERTIES
        // ═══════════════════════════════════════════════════

        // Unique identifier for this drill
        public Guid Id { get; set; }

        // The user who created this drill (coach or system)
        public Guid CreatedBy { get; set; }

        // The name of this drill
        public string Name { get; set; } // e.g., "Agility Ladder", "Drop Step Drill"

        // A detailed description of how to perform this drill
        public string Description { get; set; }

        // ───────────────────────────────────────────────────
        // DRILL DETAILS
        // ───────────────────────────────────────────────────

        // The general type or category of this drill
        public string Category { get; set; } // e.g., "Speed", "Strength", "Footwork", "Reaction"

        // The specific skill this drill trains
        // Used by ScheduleGenerator to match drills to athlete target areas
        public string SkillCategory { get; set; } // e.g., "Shooting", "Defense", "Speed"

        // How long this drill takes to complete in minutes (one set)
        public int Duration { get; set; }

        // How hard this drill is: 1=Easy, 2=Medium, 3=Hard
        // Named Difficulty (not DifficultyLevel) to match ScheduleGenerator usage
        public int Difficulty { get; set; }

        // Which sport this drill is designed for
        public string Sport { get; set; } // e.g., "Basketball", "Soccer", "Baseball"

        // Which skill area this drill helps improve
        public string TargetArea { get; set; } // e.g., "Shooting", "Speed", "Defense"

        // What equipment is needed to perform this drill
        public string EquipmentNeeded { get; set; } // e.g., "Agility Ladder, Cones" or "None"

        // How many times to repeat this drill in a session
        public int Sets { get; set; }

        // How many repetitions per set
        public int Reps { get; set; }

        // Rest time between sets in seconds
        public int RestBetweenSetsSeconds { get; set; }

        // Whether this drill is currently available for coaches and athletes to use
        public bool IsActive { get; set; }

        // ───────────────────────────────────────────────────
        // METADATA
        // ───────────────────────────────────────────────────

        // When this drill was first added to the system
        public DateTime DateCreated { get; set; }

        // When this drill was last modified
        public DateTime LastUpdated { get; set; }

        // ═══════════════════════════════════════════════════
        // CONSTRUCTOR
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Default constructor - sets up a new drill with safe default values
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public Drill()
        {
            Id = Guid.NewGuid();              // generate a unique ID for this drill
            IsActive = true;                  // new drills are active by default
            Difficulty = 1;                   // default to easy difficulty
            Duration = 15;                    // default to 15 minutes per set
            Sets = 1;                         // default to 1 set
            Reps = 10;                        // default to 10 reps per set
            RestBetweenSetsSeconds = 60;      // default to 60 seconds rest between sets
            EquipmentNeeded = "None";         // default to no equipment needed
            DateCreated = DateTime.Now;       // record when it was created
            LastUpdated = DateTime.Now;       // set last updated to right now
        }

        // ═══════════════════════════════════════════════════
        // METHODS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Converts the difficulty number to a readable label
        ///
        /// 1 = Easy   (beginner level)
        /// 2 = Medium (intermediate level)
        /// 3 = Hard   (advanced level)
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetDifficultyLabel()
        {
            // Return a readable label based on the difficulty number
            if (Difficulty == 1)
                return "Easy";       // good for beginners
            else if (Difficulty == 2)
                return "Medium";     // good for intermediate athletes
            else if (Difficulty == 3)
                return "Hard";       // good for advanced athletes
            else
                return "Unknown";    // catch any invalid values outside 1-3
        }

        /// <summary>
        /// Returns a readable description of what category this drill belongs to
        /// Converts the short category code into a full readable label
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetCategoryLabel()
        {
            // Return a full description based on the category code
            if (Category == "Speed")
                return "Speed and Agility Training";
            else if (Category == "Strength")
                return "Strength and Power Training";
            else if (Category == "Footwork")
                return "Footwork and Coordination Training";
            else if (Category == "Reaction")
                return "Reaction Time and Timing Training";
            else if (Category == "Endurance")
                return "Cardio and Endurance Training";
            else if (Category == "Technique")
                return "Skill and Technique Training";
            else if (Category == "Defense")
                return "Defensive Skills Training";
            else if (Category == "Shooting")
                return "Shooting and Accuracy Training";
            else
                return Category; // return the raw value if it is not a known category
        }

        /// <summary>
        /// Calculates the total time this drill takes including all sets and rest periods
        ///
        /// FORMULA:
        /// - Total drill time = Duration x Sets
        /// - Total rest time  = RestBetweenSetsSeconds x (Sets - 1) converted to minutes
        /// - Total time       = drill time + rest time
        ///
        /// EXAMPLE:
        /// - Duration = 10 minutes, Sets = 3, Rest = 60 seconds
        /// - Drill time = 10 x 3 = 30 minutes
        /// - Rest time  = 60 x 2 = 120 seconds = 2 minutes
        /// - Total time = 30 + 2 = 32 minutes
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public int GetTotalTime()
        {
            // Calculate total active drill time (duration x number of sets)
            int totalDrillTime = Duration * Sets;

            // Calculate total rest time between sets in minutes
            // There is one less rest period than sets
            // Example: 3 sets = 2 rest periods between them
            int totalRestMinutes = (RestBetweenSetsSeconds * (Sets - 1)) / 60;

            // Return the combined total time in minutes
            return totalDrillTime + totalRestMinutes;
        }

        /// <summary>
        /// Returns a one line summary of this drill
        /// Useful for displaying in lists and dropdowns
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetSummary()
        {
            // Build a compact one line description of the drill
            return $"{Name} | {GetCategoryLabel()} | {GetDifficultyLabel()} | " +
                   $"{Duration} min x {Sets} sets | Equipment: {EquipmentNeeded}";
        }

        /// <summary>
        /// Marks this drill as inactive so it no longer appears in schedule generation
        /// Use this instead of deleting drills so history is preserved
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public void Deactivate()
        {
            IsActive = false;              // hide this drill from schedule generation
            LastUpdated = DateTime.Now;    // record when it was deactivated
        }

        /// <summary>
        /// Marks this drill as active again so it appears in schedule generation
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public void Activate()
        {
            IsActive = true;               // make this drill available again
            LastUpdated = DateTime.Now;    // record when it was reactivated
        }

        // ═══════════════════════════════════════════════════
        // TOSTRING
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Returns a readable summary of this drill
        /// Useful for displaying in console output or debug logs
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public override string ToString()
        {
            // Return a formatted summary with the most important details
            return $"{Name} ({GetCategoryLabel()}) - " +
                   $"{GetDifficultyLabel()} - " +
                   $"{Duration} min x {Sets} sets - " +
                   $"Sport: {Sport} - " +
                   $"Active: {IsActive}";
        }
    }
}