using SportsTrainingManager.Models;
using System;
using System.Collections.Generic;

namespace SportsTrainingManager
{
    /// <summary>
    /// DrillDatabase_4Sports.cs - Simplified drill database with 4 sports
    /// 
    /// Contains:
    /// - 10 Baseball Training Skill Combinations
    /// - 10 Football Training Skill Combinations
    /// - 10 Soccer Training Skill Combinations
    /// - PLUS custom Softball drills for Rovy family
    /// 
    /// TIME COMPLEXITY: O(1) for retrieval
    /// SPACE COMPLEXITY: O(n) where n = drills
    /// </summary>
    public static class DrillDatabase
    {
        /// <summary>
        /// Get all pre-loaded drills
        /// </summary>
        public static List<Drill> GetAllDrills()
        {
            return new List<Drill>
            {
                // ===== BASEBALL TRAINING DRILLS (10) =====

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111111"),
                    Name = "Infield: Backhand Play + Force Out Finish",
                    Description = "Executing a backhanded ground ball catch while moving laterally, immediately followed by a precise throw to second base for a force out.",
                    SkillCategory = "Infield",
                    Difficulty = 2,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111112"),
                    Name = "Baserunning: Rounding Second + Decision Making",
                    Description = "Running a wide turn around second base while simultaneously reading the outfielder's throw to decide whether to advance to third or return safely.",
                    SkillCategory = "Baserunning",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111113"),
                    Name = "Outfield: Drop Step + Distance Throw",
                    Description = "Performing a deep drop step to chase a fly ball overhead, catching it on the run, and delivering a long-distance strike to a cutoff man or the plate.",
                    SkillCategory = "Outfield",
                    Difficulty = 3,
                    Duration = 30,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111114"),
                    Name = "Hitting: Weight Load + Rotational Sweep",
                    Description = "Shifting weight back into a stacked position before exploding forward with a medicine ball-style rotational swing to maximize bat speed.",
                    SkillCategory = "Hitting",
                    Difficulty = 3,
                    Duration = 35,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111115"),
                    Name = "Defense: Pitcher Cover + Tag Play",
                    Description = "Coordinating the pitcher's sprint to cover first base on a ground ball with the first baseman's throw and subsequent tag of the runner.",
                    SkillCategory = "Defense",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111116"),
                    Name = "Agility: Ickey Shuffle + Reaction Start",
                    Description = "Using a ladder to perform an Ickey Shuffle for foot coordination, then immediately reacting to a coach's verbal cue to sprint in a specific direction.",
                    SkillCategory = "Agility",
                    Difficulty = 2,
                    Duration = 15,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111117"),
                    Name = "Catching: Receiving + Pick-off Throw",
                    Description = "Framing a pitch at the edge of the zone and instantly transitioning into a lightning-fast throw to a base to catch a runner leaning.",
                    SkillCategory = "Catching",
                    Difficulty = 3,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111118"),
                    Name = "Bunting: Pivot + Zone Control",
                    Description = "Pivoting the feet into a square stance while controlling the bat angle to push the ball into specific pre-determined bunt zones.",
                    SkillCategory = "Bunting",
                    Difficulty = 1,
                    Duration = 15,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111119"),
                    Name = "Pitching: Leg Drive + Arm Path",
                    Description = "Generating explosive power from the lower body during the stride while maintaining a consistent arm care band-style mechanical path.",
                    SkillCategory = "Pitching",
                    Difficulty = 3,
                    Duration = 40,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111120"),
                    Name = "Defense: Cutoff + Relay Throw",
                    Description = "Relaying a deep outfield ball by turning toward the target and delivering a quick, accurate throw in one continuous motion.",
                    SkillCategory = "Defense",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                // ===== FOOTBALL TRAINING DRILLS (10) =====

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222221"),
                    Name = "Receiving: Slant Route + Catch in Traffic",
                    Description = "Executing a sharp 45-degree slant cut at full speed followed by a high-point catch while maintaining focus under simulated defensive pressure.",
                    SkillCategory = "Receiving",
                    Difficulty = 3,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222222"),
                    Name = "Defense: Defensive Slide + Lateral Power",
                    Description = "Using low-center-of-gravity slides combined with explosive skater jumps to stay in front of agile offensive players.",
                    SkillCategory = "Defense",
                    Difficulty = 2,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222223"),
                    Name = "Conditioning: Bear Crawl + Fumble Recovery",
                    Description = "Performing a 10-yard bear crawl for strength, then immediately diving to scoop a loose ball and returning it to the starting line.",
                    SkillCategory = "Conditioning",
                    Difficulty = 2,
                    Duration = 15,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222224"),
                    Name = "Agility: X-Drill + Change of Angle",
                    Description = "Combining rapid footwork changes with 90-degree turns and angle adjustments to mirror a ball carrier's movement.",
                    SkillCategory = "Agility",
                    Difficulty = 2,
                    Duration = 18,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222225"),
                    Name = "Speed: Resisted Start + Maximum Velocity Sprint",
                    Description = "Using resistance bands for the initial 3-point start, then releasing tension to transition into an unresisted top-speed sprint.",
                    SkillCategory = "Speed",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222226"),
                    Name = "Defense: Pressure + Covering",
                    Description = "Putting immediate physical pressure on an attacking player while simultaneously positioning yourself to cover passing lanes for a potential steal.",
                    SkillCategory = "Defense",
                    Difficulty = 3,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222227"),
                    Name = "Blocking: Drive Block + Footwork Breakdown",
                    Description = "Forcefully driving off the line of scrimmage and then quickly breaking down into a balanced stance to react to a defender's counter-move.",
                    SkillCategory = "Blocking",
                    Difficulty = 2,
                    Duration = 22,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222228"),
                    Name = "Special Teams: Kick + Directional Accuracy",
                    Description = "Executing a full-speed kick with the fundamental motor skill of balance to ensure the ball lands in a specific targeted corner of the field.",
                    SkillCategory = "Special Teams",
                    Difficulty = 3,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222229"),
                    Name = "Ball Carrying: Juke + Stiff Arm",
                    Description = "Performing a lateral change of direction (juke) while using the non-carrying arm to maintain distance from a defender.",
                    SkillCategory = "Ball Carrying",
                    Difficulty = 2,
                    Duration = 18,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222230"),
                    Name = "Agility: Carioca + 180-Degree Turn",
                    Description = "Using a carioca step for hip mobility, immediately followed by a full 180-degree turn to transition into a backpedal for defensive coverage.",
                    SkillCategory = "Agility",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                // ===== SOCCER TRAINING DRILLS (10) =====

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333331"),
                    Name = "Midfield: Shoulder Check + Turn on Half-Turn",
                    Description = "Scanning the field over the shoulder before receiving a pass to immediately turn and face forward with the first touch.",
                    SkillCategory = "Midfield",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333332"),
                    Name = "Dribbling: Speed Dribble + Lateral Cut",
                    Description = "Driving the ball forward at high speed and then using a quick inside or outside foot touch to change direction around a defender or cone.",
                    SkillCategory = "Dribbling",
                    Difficulty = 2,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333333"),
                    Name = "Passing: One-Touch Pass + Movement into Space",
                    Description = "Executing a precise one-touch pass to a teammate and immediately sprinting to an open pocket of space to receive a return ball (wall pass).",
                    SkillCategory = "Passing",
                    Difficulty = 3,
                    Duration = 30,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333334"),
                    Name = "Defense: Curved Run + 2v1 Positioning",
                    Description = "Curving a defensive run to force an attacker toward the sideline while managing the 2v1 positioning between the ball and the goal.",
                    SkillCategory = "Defense",
                    Difficulty = 3,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333335"),
                    Name = "Finishing: Dribble Entry + First-Time Shot",
                    Description = "Dribbling through a cone square to build rhythm before delivering an immediate shot on goal using the laces or inside of the foot.",
                    SkillCategory = "Finishing",
                    Difficulty = 3,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333336"),
                    Name = "Ball Control: Trapping + Immediate Release",
                    Description = "Stopping a ball cleanly out of the air or on the ground and finishing with a pass to a teammate before a defender can close in.",
                    SkillCategory = "Ball Control",
                    Difficulty = 2,
                    Duration = 18,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333337"),
                    Name = "Agility: Ladder Drill + Burst Acceleration",
                    Description = "Completing a footwork pattern in an agility ladder and transitioning directly into a 15-yard maximum effort sprint.",
                    SkillCategory = "Agility",
                    Difficulty = 1,
                    Duration = 15,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333338"),
                    Name = "Tactical: Width Play + Depth Finding",
                    Description = "Spreading the attacking front to create width while simultaneously looking for a through-ball that provides depth behind the defense.",
                    SkillCategory = "Tactical",
                    Difficulty = 3,
                    Duration = 30,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333339"),
                    Name = "Passing: Pass Accuracy + Calling Name",
                    Description = "Executing a pass to a moving teammate while verbally calling their name to improve communication and situational awareness under pressure.",
                    SkillCategory = "Passing",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333340"),
                    Name = "Physicality: Shielding + Turning",
                    Description = "Using body shape to protect the ball from a defender (shielding) and then using a low center of gravity to pivot away into space.",
                    SkillCategory = "Physicality",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                // ===== SOFTBALL DRILLS (ROVY FAMILY) =====

                new Drill
                {
                    Id = new Guid("44444444-4444-4444-4444-444444444441"),
                    Name = "Outfield: Drop Step + Over-The-Shoulder Catch",
                    Description = "Performing a drop step back while tracking the ball overhead, executing an over-the-shoulder catch while in full motion.",
                    SkillCategory = "Outfield",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("44444444-4444-4444-4444-444444444442"),
                    Name = "Hitting: Weight Load + Explosive Hip Rotation",
                    Description = "Shifting weight back into a loaded position before explosively rotating hips forward to generate maximum bat speed and power.",
                    SkillCategory = "Hitting",
                    Difficulty = 2,
                    Duration = 25,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("44444444-4444-4444-4444-444444444443"),
                    Name = "Infield: Ground Ball Footwork + Quick Release",
                    Description = "Positioning feet for ground ball approach with rapid directional steps, fielding cleanly, and making a quick release throw to base.",
                    SkillCategory = "Infield",
                    Difficulty = 2,
                    Duration = 20,
                    DateCreated = DateTime.Now
                },

                new Drill
                {
                    Id = new Guid("44444444-4444-4444-4444-444444444444"),
                    Name = "Pitching: Windmill Mechanics + Rising Fastball",
                    Description = "Executing proper windmill arm motion while generating explosive leg drive to deliver a rising fastball with velocity and movement.",
                    SkillCategory = "Pitching",
                    Difficulty = 3,
                    Duration = 35,
                    DateCreated = DateTime.Now
                }
            };
        }

        /// <summary>
        /// Get drills by sport
        /// TIME COMPLEXITY: O(n)
        /// </summary>
        public static List<Drill> GetDrillsBySport(string sport)
        {
            var allDrills = GetAllDrills();
            var filtered = new List<Drill>();

            foreach (var drill in allDrills)
            {
                if (sport.Equals("Baseball", StringComparison.OrdinalIgnoreCase))
                {
                    if (drill.Id.ToString().StartsWith("11111111"))
                        filtered.Add(drill);
                }
                else if (sport.Equals("Football", StringComparison.OrdinalIgnoreCase))
                {
                    if (drill.Id.ToString().StartsWith("22222222"))
                        filtered.Add(drill);
                }
                else if (sport.Equals("Soccer", StringComparison.OrdinalIgnoreCase))
                {
                    if (drill.Id.ToString().StartsWith("33333333"))
                        filtered.Add(drill);
                }
                else if (sport.Equals("Softball", StringComparison.OrdinalIgnoreCase))
                {
                    if (drill.Id.ToString().StartsWith("44444444"))
                        filtered.Add(drill);
                }
            }

            return filtered;
        }

        /// <summary>
        /// Get drills by category
        /// TIME COMPLEXITY: O(n)
        /// </summary>
        public static List<Drill> GetDrillsByCategory(string category)
        {
            var allDrills = GetAllDrills();
            var filtered = new List<Drill>();

            foreach (var drill in allDrills)
            {
                if (drill.SkillCategory.Equals(category, StringComparison.OrdinalIgnoreCase))
                    filtered.Add(drill);
            }

            return filtered;
        }

        /// <summary>
        /// Get drills by difficulty level
        /// TIME COMPLEXITY: O(n)
        /// </summary>
        public static List<Drill> GetDrillsByDifficulty(int difficulty)
        {
            var allDrills = GetAllDrills();
            var filtered = new List<Drill>();

            foreach (var drill in allDrills)
            {
                if (drill.Difficulty == difficulty)
                    filtered.Add(drill);
            }

            return filtered;
        }

        /// <summary>
        /// Get a specific drill by name
        /// TIME COMPLEXITY: O(n)
        /// </summary>
        public static Drill GetDrillByName(string name)
        {
            var allDrills = GetAllDrills();

            foreach (var drill in allDrills)
            {
                if (drill.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return drill;
            }

            return null;
        }

        /// <summary>
        /// Get a random drill
        /// </summary>
        public static Drill GetRandomDrill()
        {
            var random = new Random();
            var allDrills = GetAllDrills();
            return allDrills[random.Next(allDrills.Count)];
        }

        /// <summary>
        /// Print all drills organized by sport
        /// </summary>
        public static void PrintAllDrills()
        {
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║          🏆 DRILL DATABASE - 4 SPORTS 🏆                       ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");

            var baseballDrills = GetDrillsBySport("Baseball");
            Console.WriteLine($"⚾ BASEBALL DRILLS ({baseballDrills.Count})");
            PrintDrillList(baseballDrills);

            var footballDrills = GetDrillsBySport("Football");
            Console.WriteLine($"\n🏈 FOOTBALL DRILLS ({footballDrills.Count})");
            PrintDrillList(footballDrills);

            var soccerDrills = GetDrillsBySport("Soccer");
            Console.WriteLine($"\n⚽ SOCCER DRILLS ({soccerDrills.Count})");
            PrintDrillList(soccerDrills);

            var softballDrills = GetDrillsBySport("Softball");
            Console.WriteLine($"\n🥎 SOFTBALL DRILLS ({softballDrills.Count})");
            PrintDrillList(softballDrills);

            Console.WriteLine("\n════════════════════════════════════════════════════════════════\n");
        }

        /// <summary>
        /// Helper to print a list of drills
        /// </summary>
        private static void PrintDrillList(List<Drill> drills)
        {
            for (int i = 0; i < drills.Count; i++)
            {
                var drill = drills[i];
                string difficultyLabel = drill.Difficulty == 1 ? "⭐ Beginner" :
                                        drill.Difficulty == 2 ? "⭐⭐ Intermediate" : "⭐⭐⭐ Advanced";

                Console.WriteLine($"{i + 1}. {drill.Name}");
                Console.WriteLine($"   {drill.SkillCategory} | {drill.Duration} min | {difficultyLabel}\n");
            }
        }
    }
}
