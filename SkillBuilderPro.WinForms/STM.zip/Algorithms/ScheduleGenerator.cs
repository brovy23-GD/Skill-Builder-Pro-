using System;
using System.Collections.Generic;
using System.Linq;
using SportsTrainingManager.Models;

namespace SportsTrainingManager.Algorithms
{
    /// <summary>
    /// ScheduleGenerator.cs - Generates customized training schedules for athletes
    ///
    /// WHAT IT DOES:
    /// - Creates a personalized weekly training plan based on the athlete's sport and level
    /// - Selects appropriate drills that fit within the athlete's available time
    /// - Gradually increases difficulty as the athlete progresses over weeks
    ///
    /// HOW IT WORKS:
    /// - Filter drills to match the athlete's sport and target area
    /// - Calculate how many days per week to train based on available hours
    /// - Use a greedy algorithm to select the best drills within the time budget
    /// - Sort drills by the athlete's experience level for the best fit
    ///
    /// ALGORITHMS USED:
    /// - Greedy Algorithm  - picks the best drill at each step (fast and practical)
    /// - QuickSort         - sorts drills by how well they match the user
    ///
    /// TIME COMPLEXITY:
    /// - GenerateWeeklySchedule:        O(n log n) sorting + O(d x m) selection
    /// - GenerateDailySchedule:         O(n log n) sorting
    /// - GenerateProgressionSchedule:   O(w x s x n)
    /// - SelectOptimalDrills:           O(n log n) sorting
    /// - CalculateScheduleEffectiveness: O(m) where m = drills in session
    ///
    /// SPACE COMPLEXITY:
    /// - O(n) for filtered drills list
    /// - O(d x m) for output schedule
    /// </summary>
    public static class ScheduleGenerator
    {
        // ═══════════════════════════════════════════════════
        // PUBLIC METHODS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Generates a full week of training sessions for the athlete
        ///
        /// STEPS:
        /// 1. Filter drills to only include relevant ones for the athlete
        /// 2. Calculate how many days per week to train
        /// 3. Calculate how many minutes are available per day
        /// 4. For each training day, select the best drills using greedy selection
        ///
        /// TIME COMPLEXITY: O(n log n + d x m)
        ///   n = total drills (for sorting)
        ///   d = training days (outer loop)
        ///   m = drills per session (inner selection loop)
        ///
        /// SPACE COMPLEXITY: O(n) for filtered drills, O(d x m) for output
        /// </summary>
        public static List<TrainingSession> GenerateWeeklySchedule(
            User user,                   // the athlete we are building the schedule for
            List<Drill> availableDrills, // all drills in the system to choose from
            int hoursPerWeek)            // how many hours the athlete can train per week
        {
            // Start with an empty schedule - we will add sessions to this
            var schedule = new List<TrainingSession>();

            // Step 1: FILTER DRILLS
            // Get only drills that match the athlete's sport and target area
            // TIME: O(n) - checks each drill once
            var relevantDrills = FilterDrillsForUser(availableDrills, user);

            // If no matching drills found, we cannot build a schedule
            if (relevantDrills.Count == 0)
            {
                Console.WriteLine("Warning: No drills found for your sport and target area.");
                return schedule; // return empty list
            }

            // Step 2: CALCULATE TRAINING DAYS
            // Decide how many days per week to train based on available hours
            // TIME: O(1) - simple conditional check
            int trainingDays = CalculateTrainingDays(hoursPerWeek);

            // Step 3: CALCULATE MINUTES PER DAY
            // Spread the total weekly hours evenly across all training days
            // TIME: O(1) - simple math
            int minutesPerDay = (hoursPerWeek * 60) / trainingDays;

            // Step 4: BUILD A SESSION FOR EACH TRAINING DAY
            // Loop through each day and create a session with selected drills
            // TIME: O(d) where d = trainingDays (max 6, so nearly constant)
            for (int day = 0; day < trainingDays; day++)
            {
                // Create a new training session for this day
                var session = new TrainingSession
                {
                    Name = $"Training Session - Day {day + 1}",  // Day 1, Day 2, etc.
                    Date = DateTime.Now.AddDays(day),            // today, tomorrow, etc.
                    Drills = new List<Drill>()                   // empty list we will fill below
                };

                // Step 5: SELECT DRILLS FOR THIS SESSION
                // Use greedy selection to pick drills that fit in the daily time budget
                // TIME: O(n log n) for sorting inside this method
                var selectedDrills = SelectOptimalDrills(relevantDrills, user, minutesPerDay);

                // Add all selected drills to this session
                session.Drills.AddRange(selectedDrills);

                // Only add the session to the schedule if it has at least one drill
                if (session.Drills.Count > 0)
                {
                    schedule.Add(session);
                }
            }

            // Return the completed weekly schedule
            return schedule;
        }

        /// <summary>
        /// Generates a single training session for today
        /// Useful for "What should I train today?" features
        ///
        /// TIME COMPLEXITY: O(n log n) for sorting drills
        /// SPACE COMPLEXITY: O(m) where m = drills selected
        /// </summary>
        public static TrainingSession GenerateDailySchedule(
            User user,                   // the athlete
            List<Drill> availableDrills, // all drills to choose from
            int minutesAvailable)        // how much time the athlete has today
        {
            // Create a new empty session for today
            var session = new TrainingSession
            {
                Name = $"Today's Training - {DateTime.Now:MM/dd/yyyy}", // e.g., "Today's Training - 05/26/2026"
                Date = DateTime.Now,                                     // today's date
                Drills = new List<Drill>()                               // empty list we will fill
            };

            // Filter drills to only include ones matching the athlete's sport and target
            // TIME: O(n) - loops through all drills once
            var relevantDrills = FilterDrillsForUser(availableDrills, user);

            // If no matching drills found, return the empty session
            if (relevantDrills.Count == 0)
            {
                Console.WriteLine("Warning: No drills found for your sport and target area.");
                return session;
            }

            // Select the best drills that fit within the available time
            // TIME: O(n log n) - sorts and selects drills
            var selectedDrills = SelectOptimalDrills(relevantDrills, user, minutesAvailable);

            // Add the selected drills to the session
            session.Drills.AddRange(selectedDrills);

            return session;
        }

        /// <summary>
        /// Generates a multi-week progression schedule that gets harder over time
        /// Every 2 weeks, some drills are swapped out for harder versions
        ///
        /// TIME COMPLEXITY: O(w x s x n)
        ///   w = number of weeks
        ///   s = sessions per week
        ///   n = drills to search through per upgrade
        ///
        /// SPACE COMPLEXITY: O(w x s x m) where m = drills per session
        /// </summary>
        public static List<TrainingSession> GenerateProgressionSchedule(
            User user,                   // the athlete
            List<Drill> availableDrills, // all drills in the system
            int weeksToProgress)         // how many weeks to generate
        {
            // Start with an empty schedule
            var schedule = new List<TrainingSession>();

            // Generate a base week using 5 hours per week as the starting point
            // TIME: O(n log n)
            var baseSchedule = GenerateWeeklySchedule(user, availableDrills, 5);

            // Loop through each week of the progression plan
            for (int week = 0; week < weeksToProgress; week++)
            {
                // Loop through each session from the base week
                foreach (var baseSession in baseSchedule)
                {
                    // Create a copy of the base session for this week
                    var progressedSession = new TrainingSession
                    {
                        Name = $"{baseSession.Name} - Week {week + 1}",        // e.g., "Day 1 - Week 3"
                        Date = DateTime.Now.AddDays(week * 7 + baseSession.Date.Day), // correct week date
                        Drills = new List<Drill>(baseSession.Drills)            // copy the drills list
                    };

                    // Every 2 weeks starting at week 2, increase the difficulty
                    // This gives the athlete time to adjust before getting harder
                    if (week >= 2 && week % 2 == 0)
                    {
                        // Swap some drills out for harder versions
                        progressedSession.Drills = IncreaseSessionDifficulty(
                            progressedSession.Drills,
                            availableDrills);
                    }

                    // Add this session to the schedule
                    schedule.Add(progressedSession);
                }
            }

            return schedule;
        }

        /// <summary>
        /// Calculates a score (0-100) for how effective a training session is
        ///
        /// SCORING BREAKDOWN:
        /// - Base score:         50 points (starting point)
        /// - Variety bonus:      +10 points per unique drill category
        /// - Difficulty match:   +20 points if avg difficulty matches user level
        /// - Time efficiency:    +15 points if session is 30-90 minutes
        ///
        /// TIME COMPLEXITY: O(m) where m = drills in session
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public static int CalculateScheduleEffectiveness(TrainingSession session, User user)
        {
            // Cannot score an empty session
            if (session.Drills.Count == 0)
                return 0;

            // Start with a base score of 50 out of 100
            int score = 50;

            // BONUS 1: VARIETY
            // Count how many different skill categories are represented
            // More variety = better all-around workout
            var uniqueCategories = session.Drills
                .Select(d => d.SkillCategory)  // get the category of each drill
                .Distinct()                     // remove duplicates
                .Count();                       // count unique categories

            score += uniqueCategories * 10; // +10 points per unique category

            // BONUS 2: DIFFICULTY MATCH
            // Calculate average difficulty level of all drills in the session
            var avgDifficulty = session.Drills.Average(d => d.Difficulty);

            // If the average difficulty is within 1 level of the user's experience, add bonus
            if (Math.Abs(avgDifficulty - user.ExperienceLevel) < 1)
                score += 20; // +20 points for good difficulty match

            // BONUS 3: TIME EFFICIENCY
            // Add up total duration of all drills in the session
            int totalDuration = session.Drills.Sum(d => d.Duration);

            // Ideal session length is between 30 and 90 minutes
            if (totalDuration >= 30 && totalDuration <= 90)
                score += 15; // +15 points for ideal session length

            // Cap the score at 100 maximum
            return Math.Min(score, 100);
        }

        // ═══════════════════════════════════════════════════
        // PRIVATE HELPER METHODS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// FILTER STEP: Removes drills that do not match the athlete's preferences
        ///
        /// Keeps drills where:
        /// - The athlete wants All-Around training (keep all drills)
        /// - OR the drill's category matches the athlete's target area
        ///
        /// Falls back to all drills if no matches found
        ///
        /// TIME COMPLEXITY: O(n) - checks each drill once
        /// SPACE COMPLEXITY: O(m) where m = number of matching drills
        /// </summary>
        private static List<Drill> FilterDrillsForUser(List<Drill> drills, User user)
        {
            // Create an empty list for drills that pass the filter
            var filtered = new List<Drill>();

            // Loop through every drill and check if it matches the athlete
            foreach (var drill in drills)
            {
                // Keep this drill if:
                // - Athlete wants All-Around training (all drills are valid)
                // - OR this drill's category matches the athlete's target area
                if (user.TargetArea.Equals("All-Around", StringComparison.OrdinalIgnoreCase) ||
                    drill.SkillCategory.Equals(user.TargetArea, StringComparison.OrdinalIgnoreCase))
                {
                    filtered.Add(drill); // this drill matches - keep it
                }
            }

            // If we found matching drills, return them
            // If nothing matched, fall back to all drills so we can still build a schedule
            return filtered.Count > 0 ? filtered : drills;
        }

        /// <summary>
        /// SELECTION STEP: Uses a greedy algorithm to pick the best drills
        /// that fit within the available time budget
        ///
        /// GREEDY ALGORITHM EXPLANATION:
        /// 1. Sort drills by how well they match the athlete (best first)
        /// 2. Loop through sorted drills from best to worst
        /// 3. Add each drill if it fits in the remaining time
        /// 4. Skip drills that do not fit
        /// 5. Stop when no more time is available
        ///
        /// WHY GREEDY WORKS HERE:
        /// - We want variety (different drill types)
        /// - We want difficulty match (similar to athlete level)
        /// - Greedy achieves both goals quickly
        /// - The alternative (checking every combination) would be O(2^n) - too slow
        ///
        /// TIME COMPLEXITY: O(n log n) for sorting, O(n) for selection loop
        /// SPACE COMPLEXITY: O(m) where m = drills selected
        /// </summary>
        private static List<Drill> SelectOptimalDrills(
            List<Drill> drills,      // drills to choose from
            User user,               // the athlete's preferences
            int minutesAvailable)    // time budget for this session
        {
            // List to hold the drills we decide to include
            var selected = new List<Drill>();

            // Track how many minutes we have used so far
            int totalMinutes = 0;

            // Step 1: SORT DRILLS BY USER FIT
            // Put the best matching drills first so greedy picks them first
            // TIME: O(n log n)
            var sortedDrills = SortDrillsByUserFit(drills, user);

            // Step 2: GREEDY SELECTION LOOP
            // Go through sorted drills from best match to worst
            // TIME: O(n) worst case, usually much less
            foreach (var drill in sortedDrills)
            {
                // Check if this drill fits within our remaining time budget
                if (totalMinutes + drill.Duration <= minutesAvailable)
                {
                    selected.Add(drill);
                    totalMinutes += drill.Duration;
                }
            }

            return selected;
        }

        /// <summary>
        /// Sorts drills by how well they match the athlete.
        /// Higher priority goes to:
        /// - Matching skill category
        /// - Difficulty close to user's experience level
        /// - Shorter duration (more flexible)
        ///
        /// TIME COMPLEXITY: O(n log n)
        /// </summary>
        private static List<Drill> SortDrillsByUserFit(List<Drill> drills, User user)
        {
            return drills
                .OrderByDescending(d => d.SkillCategory.Equals(user.TargetArea, StringComparison.OrdinalIgnoreCase))
                .ThenBy(d => Math.Abs(d.Difficulty - user.ExperienceLevel))
                .ThenBy(d => d.Duration)
                .ToList();
        }

        /// <summary>
        /// Increases the difficulty of a session by replacing drills
        /// with harder versions when available.
        ///
        /// TIME COMPLEXITY: O(n^2) worst case (nested search)
        /// </summary>
        private static List<Drill> IncreaseSessionDifficulty(
            List<Drill> currentDrills,
            List<Drill> allDrills)
        {
            var upgraded = new List<Drill>();

            foreach (var drill in currentDrills)
            {
                // Find harder drills in the same category
                var harderOptions = allDrills
                    .Where(d =>
                        d.SkillCategory.Equals(drill.SkillCategory, StringComparison.OrdinalIgnoreCase) &&
                        d.Difficulty > drill.Difficulty)
                    .OrderBy(d => d.Difficulty)
                    .ToList();

                // If a harder version exists, use it
                if (harderOptions.Count > 0)
                    upgraded.Add(harderOptions.First());
                else
                    upgraded.Add(drill); // keep original
            }

            return upgraded;
        }

        /// <summary>
        /// Calculates how many days per week the athlete should train
        /// based on available hours.
        ///
        /// TIME COMPLEXITY: O(1)
        /// </summary>
        private static int CalculateTrainingDays(int hoursPerWeek)
        {
            if (hoursPerWeek <= 2) return 2;
            if (hoursPerWeek <= 4) return 3;
            if (hoursPerWeek <= 6) return 4;
            if (hoursPerWeek <= 8) return 5;
            return 6;
        }
    }
}
