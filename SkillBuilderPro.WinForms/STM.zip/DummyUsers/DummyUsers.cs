using SportsTrainingManager.Models;
using System;
using System.Collections.Generic;

namespace SportsTrainingManager
{
    /// <summary>
    /// DummyUsers_10Athletes_Final.cs - 10 DIVERSE ATHLETES for testing!
    /// 
    /// INCLUDES:
    /// - Your daughters (Rovy Family) with custom softball drills
    /// - Famous sports legends (MJ, Kobe, Ronaldo) - Advanced level
    /// - Famous non-athletes (to show Beginner/Intermediate) - Different challenge levels
    /// 
    /// This demonstrates different difficulty levels:
    /// Advanced: Michael Jordan, Kobe Bryant, Cristiano Ronaldo
    /// Intermediate: Your daughters + other intermediate athletes
    /// Beginner: Famous people taking up sports for the first time
    /// 
    /// TIME COMPLEXITY: O(1) for retrieval
    /// SPACE COMPLEXITY: O(n) where n = 10 athletes
    /// </summary>
    public static class DummyUsers
    {
        /// <summary>
        /// Get all 10 athletes for testing
        /// </summary>
        public static List<User> GetAllDummyUsers()
        {
            return new List<User>
            {
                // ===== SPORTS LEGENDS (ADVANCED) =====

                // USER 0: MICHAEL JORDAN - BASKETBALL GOAT
                new User
                {
                    Id = new Guid("11111111-1111-1111-1111-111111111111"),
                    FullName = "Michael Jordan",
                    Email = "michael.jordan@nba.com",
                    Role = UserRole.Athlete,
                    Sport = "Basketball",
                    TargetArea = "Defensive Intensity & Clutch Shooting",
                    ExperienceLevel = 3,  // Advanced ⭐⭐⭐
                    DateCreated = new DateTime(1963, 2, 17),
                    LastLogin = new DateTime(2026, 5, 26, 15, 30, 0)
                },

                // USER 1: KOBE BRYANT - BASKETBALL LEGEND
                new User
                {
                    Id = new Guid("22222222-2222-2222-2222-222222222222"),
                    FullName = "Kobe Bryant",
                    Email = "kobe.bryant@nba.com",
                    Role = UserRole.Athlete,
                    Sport = "Basketball",
                    TargetArea = "Clutch Shooting & Footwork",
                    ExperienceLevel = 3,  // Advanced ⭐⭐⭐
                    DateCreated = new DateTime(1978, 8, 23),
                    LastLogin = new DateTime(2026, 5, 26, 9, 30, 0)
                },

                // USER 2: CRISTIANO RONALDO - SOCCER ICON
                new User
                {
                    Id = new Guid("33333333-3333-3333-3333-333333333333"),
                    FullName = "Cristiano Ronaldo",
                    Email = "cristiano.ronaldo@soccer.com",
                    Role = UserRole.Athlete,
                    Sport = "Soccer",
                    TargetArea = "Ball Control & Finishing",
                    ExperienceLevel = 3,  // Advanced ⭐⭐⭐
                    DateCreated = new DateTime(1985, 2, 5),
                    LastLogin = new DateTime(2026, 5, 25, 14, 45, 0)
                },

                // ===== ROVY FAMILY (INTERMEDIATE) =====

                // USER 3: ALLIE ROVY - SOFTBALL OUTFIELD
                new User
                {
                    Id = new Guid("44444444-4444-4444-4444-444444444444"),
                    FullName = "Allie Rovy",
                    Email = "allie.rovy@softball.com",
                    Role = UserRole.Athlete,
                    Sport = "Softball",
                    TargetArea = "Outfield: Drop Step + Over-The-Shoulder Catch",
                    ExperienceLevel = 2,  // Intermediate ⭐⭐
                    DateCreated = new DateTime(2012, 3, 15),
                    LastLogin = new DateTime(2026, 5, 26, 8, 15, 0)
                },

                // USER 4: AUBREY ROVY - SOFTBALL HITTING
                new User
                {
                    Id = new Guid("55555555-5555-5555-5555-555555555555"),
                    FullName = "Aubrey Rovy",
                    Email = "aubrey.rovy@softball.com",
                    Role = UserRole.Athlete,
                    Sport = "Softball",
                    TargetArea = "Softball Hitting: Weight Load + Explosive Hip Rotation",
                    ExperienceLevel = 2,  // Intermediate ⭐⭐
                    DateCreated = new DateTime(2010, 7, 22),
                    LastLogin = new DateTime(2026, 5, 26, 7, 45, 0)
                },

                // USER 5: KALEIGH ROVY - SOFTBALL INFIELD
                new User
                {
                    Id = new Guid("66666666-6666-6666-6666-666666666666"),
                    FullName = "Kaleigh Rovy",
                    Email = "kaleigh.rovy@softball.com",
                    Role = UserRole.Athlete,
                    Sport = "Softball",
                    TargetArea = "Softball Infield: Ground Ball Footwork + Quick Release",
                    ExperienceLevel = 1,  // Beginner ⭐ (Youngest, just starting)
                    DateCreated = new DateTime(2014, 1, 15),
                    LastLogin = new DateTime(2026, 5, 26, 14, 20, 0)
                },

                // ===== FAMOUS NON-ATHLETES (BEGINNER - Learning sports for first time) =====

                // USER 6: KEVIN HART - COMEDIAN (Starting Baseball)
                new User
                {
                    Id = new Guid("77777777-7777-7777-7777-777777777777"),
                    FullName = "Kevin Hart",
                    Email = "kevin.hart@baseball.com",
                    Role = UserRole.Athlete,
                    Sport = "Baseball",
                    TargetArea = "Bunting: Pivot + Zone Control",
                    ExperienceLevel = 1,  // Beginner ⭐ (First time athlete)
                    DateCreated = new DateTime(2024, 1, 10),
                    LastLogin = new DateTime(2026, 5, 26, 10, 0, 0)
                },

                // USER 7: ELON MUSK - TECH ENTREPRENEUR (Starting Football)
                new User
                {
                    Id = new Guid("88888888-8888-8888-8888-888888888888"),
                    FullName = "Elon Musk",
                    Email = "elon.musk@football.com",
                    Role = UserRole.Athlete,
                    Sport = "Football",
                    TargetArea = "Conditioning: Bear Crawl + Fumble Recovery",
                    ExperienceLevel = 1,  // Beginner ⭐ (Just learning)
                    DateCreated = new DateTime(2024, 3, 5),
                    LastLogin = new DateTime(2026, 5, 25, 11, 30, 0)
                },

                // USER 8: ARIANA GRANDE - SINGER (Starting Soccer)
                new User
                {
                    Id = new Guid("99999999-9999-9999-9999-999999999999"),
                    FullName = "Ariana Grande",
                    Email = "ariana.grande@soccer.com",
                    Role = UserRole.Athlete,
                    Sport = "Soccer",
                    TargetArea = "Agility: Ladder Drill + Burst Acceleration",
                    ExperienceLevel = 1,  // Beginner ⭐ (New to sports)
                    DateCreated = new DateTime(2024, 2, 20),
                    LastLogin = new DateTime(2026, 5, 26, 6, 45, 0)
                },

                // USER 9: BILL GATES - TECH BILLIONAIRE (Starting Baseball)
                new User
                {
                    Id = new Guid("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
                    FullName = "Bill Gates",
                    Email = "bill.gates@baseball.com",
                    Role = UserRole.Athlete,
                    Sport = "Baseball",
                    TargetArea = "Agility: Ickey Shuffle + Reaction Start",
                    ExperienceLevel = 1,  // Beginner ⭐ (First time learner)
                    DateCreated = new DateTime(2024, 4, 1),
                    LastLogin = new DateTime(2026, 5, 25, 16, 15, 0)
                }
            };
        }

        /// <summary>
        /// Get a specific dummy user by index (0-9)
        /// 
        /// SPORTS LEGENDS (ADVANCED):
        /// 0 = Michael Jordan (Basketball)
        /// 1 = Kobe Bryant (Basketball)
        /// 2 = Cristiano Ronaldo (Soccer)
        /// 
        /// ROVY FAMILY (INTERMEDIATE & BEGINNER):
        /// 3 = Allie Rovy (Softball - Intermediate)
        /// 4 = Aubrey Rovy (Softball - Intermediate)
        /// 5 = Kaleigh Rovy (Softball - Beginner/Youngest)
        /// 
        /// FAMOUS NON-ATHLETES (BEGINNER - Learning):
        /// 6 = Kevin Hart (Baseball - Beginner)
        /// 7 = Elon Musk (Football - Beginner)
        /// 8 = Ariana Grande (Soccer - Beginner)
        /// 9 = Bill Gates (Baseball - Beginner)
        /// </summary>
        public static User GetDummyUserByIndex(int index)
        {
            if (index < 0 || index >= 10)
                throw new ArgumentOutOfRangeException(nameof(index), "Index must be between 0 and 9");

            return GetAllDummyUsers()[index];
        }

        /// <summary>
        /// Get a random dummy user
        /// </summary>
        public static User GetRandomDummyUser()
        {
            var random = new Random();
            var users = GetAllDummyUsers();
            return users[random.Next(users.Count)];
        }

        /// <summary>
        /// Get all dummy users of a specific sport
        /// </summary>
        public static List<User> GetDummyUsersBySport(string sport)
        {
            var users = GetAllDummyUsers();
            var filtered = new List<User>();

            foreach (var user in users)
            {
                if (user.Sport.Equals(sport, StringComparison.OrdinalIgnoreCase))
                {
                    filtered.Add(user);
                }
            }

            return filtered;
        }

        /// <summary>
        /// Get all dummy users of a specific experience level
        /// </summary>
        public static List<User> GetDummyUsersByExperienceLevel(int level)
        {
            var users = GetAllDummyUsers();
            var filtered = new List<User>();

            foreach (var user in users)
            {
                if (user.ExperienceLevel == level)
                {
                    filtered.Add(user);
                }
            }

            return filtered;
        }

        /// <summary>
        /// Get all Rovy family members
        /// </summary>
        public static List<User> GetRovyFamilyMembers()
        {
            var users = GetAllDummyUsers();
            var rovy = new List<User>();

            foreach (var user in users)
            {
                if (user.FullName.EndsWith("Rovy"))
                    rovy.Add(user);
            }

            return rovy;
        }

        /// <summary>
        /// Get all sports legends (Advanced athletes)
        /// </summary>
        public static List<User> GetSportsLegends()
        {
            return GetDummyUsersByExperienceLevel(3);
        }

        /// <summary>
        /// Get all famous non-athletes (Beginners learning sports)
        /// </summary>
        public static List<User> GetFamousNonAthletes()
        {
            var users = GetAllDummyUsers();
            var nonAthletes = new List<User>();

            // Non-athletes are: Kevin Hart, Elon, Ariana, Bill
            var nonAthleteNames = new[] { "Kevin Hart", "Elon Musk", "Ariana Grande", "Bill Gates" };

            foreach (var user in users)
            {
                foreach (var name in nonAthleteNames)
                {
                    if (user.FullName.Equals(name))
                        nonAthletes.Add(user);
                }
            }

            return nonAthletes;
        }

        /// <summary>
        /// Print all users organized by category
        /// </summary>
        public static void PrintAllUsers()
        {
            var users = GetAllDummyUsers();
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║     🏆 10 ATHLETES - LEGENDS, FAMILY & BEGINNERS 🏆            ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");
            Console.WriteLine($"Total Athletes: {users.Count}\n");

            // Print Sports Legends
            Console.WriteLine("⭐⭐⭐ SPORTS LEGENDS (ADVANCED)");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            var legends = GetSportsLegends();
            PrintAthleteList(legends);

            // Print Rovy Family
            Console.WriteLine("\n👨‍👩‍👧‍👦 ROVY FAMILY (INTERMEDIATE & BEGINNER)");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            var rovy = GetRovyFamilyMembers();
            PrintAthleteList(rovy);

            // Print Famous Non-Athletes
            Console.WriteLine("\n🎤 FAMOUS NON-ATHLETES (BEGINNER - Learning Sports)");
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            var nonAthletes = GetFamousNonAthletes();
            PrintAthleteList(nonAthletes);

            Console.WriteLine("\n════════════════════════════════════════════════════════════════\n");
        }

        /// <summary>
        /// Helper to print a list of athletes
        /// </summary>
        private static void PrintAthleteList(List<User> athletes)
        {
            for (int i = 0; i < athletes.Count; i++)
            {
                var u = athletes[i];
                string expLevel = u.ExperienceLevel == 1 ? "⭐ Beginner" :
                                 u.ExperienceLevel == 2 ? "⭐⭐ Intermediate" : "⭐⭐⭐ Advanced";

                Console.WriteLine($"👤 {u.FullName}");
                Console.WriteLine($"   Sport: {u.Sport} | Level: {expLevel}");
                Console.WriteLine($"   Focus: {u.TargetArea}");
                Console.WriteLine($"   Email: {u.Email}");
                Console.WriteLine($"   Joined: {u.DateCreated:MMM dd, yyyy}\n");
            }
        }

        /// <summary>
        /// Get athlete info as formatted string
        /// </summary>
        public static string GetAthleteInfo(int index)
        {
            var user = GetDummyUserByIndex(index);
            string level = user.ExperienceLevel == 1 ? "Beginner" :
                          user.ExperienceLevel == 2 ? "Intermediate" : "Advanced";
            return $"{user.FullName} ({user.Sport}) - {level}";
        }

        /// <summary>
        /// Print summary statistics
        /// </summary>
        public static void PrintAthleteStatistics()
        {
            var all = GetAllDummyUsers();
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║             📊 ATHLETE DATABASE STATISTICS 📊                  ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");

            Console.WriteLine($"Total Athletes: {all.Count}");
            Console.WriteLine($"Sports Legends (Advanced): {GetSportsLegends().Count}");
            Console.WriteLine($"Rovy Family Members: {GetRovyFamilyMembers().Count}");
            Console.WriteLine($"Famous Non-Athletes (Beginner): {GetFamousNonAthletes().Count}");

            Console.WriteLine($"\nAdvanced Athletes: {GetDummyUsersByExperienceLevel(3).Count}");
            Console.WriteLine($"Intermediate Athletes: {GetDummyUsersByExperienceLevel(2).Count}");
            Console.WriteLine($"Beginner Athletes: {GetDummyUsersByExperienceLevel(1).Count}");

            Console.WriteLine($"\nBasketball: {GetDummyUsersBySport("Basketball").Count}");
            Console.WriteLine($"Soccer: {GetDummyUsersBySport("Soccer").Count}");
            Console.WriteLine($"Baseball: {GetDummyUsersBySport("Baseball").Count}");
            Console.WriteLine($"Football: {GetDummyUsersBySport("Football").Count}");
            Console.WriteLine($"Softball: {GetDummyUsersBySport("Softball").Count}");

            Console.WriteLine("\n════════════════════════════════════════════════════════════════\n");
        }
    }
}
