using System;
using System.Windows.Forms;
using SportsTrainingManager.Models;

namespace SportsTrainingManager
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Open the login form first
            using (var loginForm = new LoginForm())
            {
                // Only open the main app if login was successful
                if (loginForm.ShowDialog() == DialogResult.OK)
                {
                    // Pass the logged in user to the main form
                    Application.Run(new MainForm(loginForm.LoggedInUser));
                }
            }
        }
    }
}