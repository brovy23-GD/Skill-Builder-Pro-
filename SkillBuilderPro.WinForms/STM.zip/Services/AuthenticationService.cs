using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using SportsTrainingManager.Models;

namespace SportsTrainingManager.Services
{
    /// <summary>
    /// AuthenticationService.cs - Handles all user login, signup, and password operations
    /// 
    /// WHAT IT DOES:
    ///   1. Manages user accounts (create new accounts, store user data)
    ///   2. Handles login/logout functionality
    ///   3. Secures passwords using hashing (one-way encryption)
    ///   4. Saves/loads user data from text files
    /// 
    /// TIME COMPLEXITY:
    ///   - LoadUsers(): O(n) where n = number of users (reads each line once)
    ///   - SignUp(): O(n) to check if username exists (linear search)
    ///   - LogIn(): O(n) to find user (linear search)
    ///   - SaveUsers(): O(n) to write all users
    /// 
    /// SPACE COMPLEXITY:
    ///   - O(n) for storing all users in memory
    /// 
    /// NOTE: For small datasets (< 10,000 users), O(n) is fast enough
    /// For larger datasets, would use hash table for O(1) lookup
    /// </summary>
    public class AuthenticationService
    {
        // ===== DATA STORAGE =====
        /// <summary>
        /// In-memory list storing all user accounts
        /// We keep this in memory for fast access during the session
        /// All data is loaded from file when app starts
        /// </summary>
        private List<User> users;

        /// <summary>
        /// File path where user data is saved
        /// Using pipe character (|) as separator between fields
        /// Example: "id|username|password|email|..."
        /// </summary>
        private const string USERS_FILE = "data/users.txt";

        /// <summary>
        /// The currently logged-in user (null if no one is logged in)
        /// Used to track who is using the app right now
        /// </summary>
        private User currentUser;

        /// <summary>
        /// Constructor - Initialize empty list for users
        /// Time Complexity: O(1)
        /// Space Complexity: O(1)
        /// </summary>
        public AuthenticationService()
        {
            // Create empty list to hold users
            users = new List<User>();
        }

        /// <summary>
        /// Loads all users from the file into memory
        /// This is called once when app starts
        /// 
        /// TIME COMPLEXITY: O(n) where n = number of lines in file
        ///   - We read each line exactly once
        ///   - We parse each line exactly once
        /// 
        /// SPACE COMPLEXITY: O(n) to store all users in list
        /// </summary>
        public void LoadUsers()
        {
            // Clear existing users (in case called multiple times)
            users.Clear();

            // Check if file exists - if not, no users yet, just return
            if (!File.Exists(USERS_FILE))
                return;

            try
            {
                // Read entire file into array of lines
                // File.ReadAllLines = efficient way to read whole file at once
                // Time: O(n) where n = file size
                var lines = File.ReadAllLines(USERS_FILE);

                // Loop through each line in the file
                // Time: O(n) - we process each line once
                foreach (var line in lines)
                {
                    // Skip empty lines (whitespace only)
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    // Parse line into User object
                    // Time: O(1) per user (constant parsing time)
                    var user = ParseUser(line);

                    // Only add if parsing was successful
                    if (user != null)
                    {
                        users.Add(user); // O(1) - adding to end of list
                    }
                }
            }
            catch (Exception ex)
            {
                // If anything goes wrong (file permissions, corrupted data)
                // Just print error and continue
                Console.WriteLine($"Error loading users: {ex.Message}");
            }
        }

        /// <summary>
        /// Saves all users currently in memory to the file
        /// This is called whenever we add/update a user
        /// 
        /// TIME COMPLEXITY: O(n) where n = number of users
        ///   - We convert each user to string once: O(1) per user
        ///   - We write all strings to file once: O(n)
        /// 
        /// SPACE COMPLEXITY: O(n) for string array
        /// </summary>
        public void SaveUsers()
        {
            try
            {
                // Convert each User object to a string (pipe-delimited format)
                // LINQ .Select() = map function (transform each item)
                // Time: O(n) - transforms each user
                var lines = users.Select(u => SerializeUser(u)).ToArray();

                // Write all lines to file
                // File.WriteAllLines = overwrites entire file atomically
                // Time: O(n) - writes each line
                File.WriteAllLines(USERS_FILE, lines);
            }
            catch (Exception ex)
            {
                // If write fails, just print error
                Console.WriteLine($"Error saving users: {ex.Message}");
            }
        }

        /// <summary>
        /// Creates new user account (Sign Up)
        /// 
        /// TIME COMPLEXITY: O(n) where n = number of existing users
        ///   - Check if username exists: O(n) linear search
        ///   - Add new user: O(1)
        ///   - Save to file: O(n)
        /// 
        /// RETURNS: (bool success, string message)
        ///   - success = true if account created, false if validation failed
        ///   - message = explanation of what happened
        /// </summary>
        public (bool success, string message) SignUp(string username, string password, string email, 
            string fullName, UserRole role, string sport, string targetArea, int experience)
        {
            // ===== VALIDATION CHECKS =====
            
            // Check 1: Username requirements
            // Username must exist and be at least 3 characters
            if (string.IsNullOrWhiteSpace(username) || username.Length < 3)
                return (false, "Username must be at least 3 characters");

            // Check 2: Password requirements
            // Password must exist and be at least 6 characters
            if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
                return (false, "Password must be at least 6 characters");

            // Check 3: Username uniqueness
            // Loop through all users and check if this username already exists
            // Time: O(n) - worst case we check all users
            // Using .Any() with lambda = functional way to check existence
            if (users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
                return (false, "Username already exists");

            // Check 4: Email format
            // Simple check: email must contain @ symbol
            // More robust check would use regex, but this is fine for basics
            if (!email.Contains("@"))
                return (false, "Invalid email format");

            // Check 5: Full name not empty
            if (string.IsNullOrWhiteSpace(fullName))
                return (false, "Full name is required");

            // ===== CREATE NEW USER =====
            
            // Create new User object with provided information
            var user = new User
            {
                Username = username,
                Password = HashPassword(password),  // O(1) - hash function
                Email = email,
                FullName = fullName,
                Role = role,
                Sport = sport,
                TargetArea = targetArea,
                ExperienceLevel = experience
            };

            // Add new user to our in-memory list
            // Time: O(1) - adding to end of list
            users.Add(user);

            // Save all users to file
            // Time: O(n) - saves all users
            SaveUsers();

            // Return success with friendly message
            return (true, $"Account created successfully! Welcome, {fullName}!");
        }

        /// <summary>
        /// Attempts to log user in with username and password
        /// 
        /// TIME COMPLEXITY: O(n) where n = number of users
        ///   - Find user by username: O(n) linear search
        ///   - Verify password: O(1)
        ///   - Update last login: O(1)
        ///   - Save: O(n)
        /// 
        /// RETURNS: (bool success, User user, string message)
        ///   - success = true if login successful
        ///   - user = the User object if successful, null otherwise
        ///   - message = explanation
        /// </summary>
        public (bool success, User user, string message) LogIn(string username, string password)
        {
            // Validate inputs aren't empty
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                return (false, null, "Username and password required");

            // Find user with matching username
            // Time: O(n) - worst case, search through all users
            // FirstOrDefault = returns first match or null
            var user = users.FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));

            // If no user found with that username
            if (user == null)
                return (false, null, "Username not found");

            // Check if password matches
            // Time: O(1) - hash and compare
            if (!VerifyPassword(password, user.Password))
                return (false, null, "Incorrect password");

            // Check if account is active (not deactivated)
            if (!user.IsActive)
                return (false, null, "Account has been deactivated");

            // Update last login time to now
            user.LastLogin = DateTime.Now;

            // Save updated last login time
            SaveUsers();

            // Set this as the current logged-in user
            currentUser = user;

            // Return success
            return (true, user, $"Welcome back, {user.FullName}!");
        }

        /// <summary>
        /// Gets the currently logged-in user
        /// 
        /// TIME COMPLEXITY: O(1) - just return reference to current user
        /// SPACE COMPLEXITY: O(1) - no new memory allocated
        /// </summary>
        public User GetCurrentUser()
        {
            // Simply return whoever is logged in (or null if nobody is)
            return currentUser;
        }

        /// <summary>
        /// Logs out the current user
        /// 
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public void LogOut()
        {
            // Set current user to null (nobody logged in now)
            currentUser = null;
        }

        /// <summary>
        /// Checks if anyone is currently logged in
        /// 
        /// TIME COMPLEXITY: O(1) - just check if null
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public bool IsLoggedIn()
        {
            // Return true if someone is logged in, false otherwise
            return currentUser != null;
        }

        /// <summary>
        /// Finds a user by their ID (GUID)
        /// 
        /// TIME COMPLEXITY: O(n) where n = number of users
        ///   - In worst case, we search through all users
        ///   - FirstOrDefault = stops at first match
        /// 
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public User GetUserById(Guid userId)
        {
            // Search for user with matching ID
            // Time: O(n) - linear search
            return users.FirstOrDefault(u => u.Id == userId);
        }

        /// <summary>
        /// Updates user profile information
        /// 
        /// TIME COMPLEXITY: O(n)
        ///   - Get user: O(n)
        ///   - Update: O(1)
        ///   - Save: O(n)
        /// 
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public bool UpdateUserProfile(User updatedUser)
        {
            // Find the existing user
            var user = GetUserById(updatedUser.Id);
            
            // If user not found, return false
            if (user == null)
                return false;

            // Update all profile fields
            user.FullName = updatedUser.FullName;
            user.Email = updatedUser.Email;
            user.PhoneNumber = updatedUser.PhoneNumber;
            user.Sport = updatedUser.Sport;
            user.TargetArea = updatedUser.TargetArea;
            user.ExperienceLevel = updatedUser.ExperienceLevel;

            // Save updated user to file
            SaveUsers();

            // If we're updating the logged-in user, update that reference too
            if (currentUser?.Id == user.Id)
                currentUser = user;

            return true;
        }

        /// <summary>
        /// Changes user's password
        /// 
        /// TIME COMPLEXITY: O(1) for verification and hashing
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public (bool success, string message) ChangePassword(string currentPassword, string newPassword)
        {
            // Check if user is logged in
            if (currentUser == null)
                return (false, "Not logged in");

            // Verify the current password is correct
            if (!VerifyPassword(currentPassword, currentUser.Password))
                return (false, "Current password is incorrect");

            // Check new password meets requirements
            if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 6)
                return (false, "New password must be at least 6 characters");

            // Hash the new password and update
            currentUser.Password = HashPassword(newPassword);

            // Save to file
            SaveUsers();

            return (true, "Password changed successfully");
        }

        /// <summary>
        /// Hashes a password using SHA256 encryption
        /// SHA256 = one-way encryption (can't decrypt back to original)
        /// Makes passwords secure even if file is compromised
        /// 
        /// TIME COMPLEXITY: O(1) - fixed computation time
        /// SPACE COMPLEXITY: O(1) - fixed output size
        /// 
        /// NOTE: In production, would use bcrypt instead (more secure)
        /// </summary>
        private string HashPassword(string password)
        {
            // Create SHA256 hasher object
            using (var sha256 = SHA256.Create())
            {
                // Convert password string to bytes (SHA256 works on bytes)
                var passwordBytes = Encoding.UTF8.GetBytes(password);

                // Hash the bytes (computes SHA256 hash)
                // Time: O(1) - fixed for fixed-size input
                var hashBytes = sha256.ComputeHash(passwordBytes);

                // Convert hash bytes back to string (Base64 encoded)
                // Base64 = safe text representation of binary data
                return Convert.ToBase64String(hashBytes);
            }
        }

        /// <summary>
        /// Verifies that a password matches a stored hash
        /// Works by hashing the provided password and comparing to stored hash
        /// If hashes match, password was correct
        /// 
        /// TIME COMPLEXITY: O(1) - hash and compare
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        private bool VerifyPassword(string password, string hash)
        {
            // Hash the provided password
            var hashOfInput = HashPassword(password);

            // Compare the hashes
            // If they match, the password was correct
            return hashOfInput.Equals(hash);
        }

        /// <summary>
        /// Converts User object to pipe-delimited string for file storage
        /// Example output: "guid|username|password_hash|email|fullname|phone|role|sport|target|exp|created|login|active"
        /// 
        /// TIME COMPLEXITY: O(1) - fixed string concatenation
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        private string SerializeUser(User user)
        {
            // Build pipe-delimited string with all user data
            // Each field separated by |
            return $"{user.Id}|{user.Username}|{user.Password}|{user.Email}|{user.FullName}|{user.PhoneNumber}|{(int)user.Role}|{user.Sport}|{user.TargetArea}|{user.ExperienceLevel}|{user.DateCreated:O}|{user.LastLogin:O}|{user.IsActive}";
        }

        /// <summary>
        /// Parses pipe-delimited string back into User object
        /// Reverse of SerializeUser()
        /// 
        /// TIME COMPLEXITY: O(1) - fixed parsing work
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        private User ParseUser(string line)
        {
            try
            {
                // Split line by pipe character to get individual fields
                var parts = line.Split('|');

                // Check if we have minimum required fields
                if (parts.Length < 13)
                    return null; // Corrupted data, skip this line

                // Reconstruct User object from fields
                return new User
                {
                    Id = Guid.Parse(parts[0]),                           // Field 0: ID
                    Username = parts[1],                                 // Field 1: Username
                    Password = parts[2],                                 // Field 2: Hashed password
                    Email = parts[3],                                    // Field 3: Email
                    FullName = parts[4],                                 // Field 4: Full name
                    PhoneNumber = parts[5],                              // Field 5: Phone
                    Role = (UserRole)int.Parse(parts[6]),               // Field 6: Role enum
                    Sport = parts[7],                                    // Field 7: Sport
                    TargetArea = parts[8],                               // Field 8: Target area
                    ExperienceLevel = int.Parse(parts[9]),              // Field 9: Experience
                    DateCreated = DateTime.Parse(parts[10]),            // Field 10: Created date
                    LastLogin = DateTime.Parse(parts[11]),              // Field 11: Last login
                    IsActive = bool.Parse(parts[12])                    // Field 12: Is active
                };
            }
            catch
            {
                // If anything goes wrong parsing, return null (skip this user)
                return null;
            }
        }
    }
}
