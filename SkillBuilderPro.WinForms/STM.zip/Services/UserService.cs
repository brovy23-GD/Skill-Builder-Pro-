using System;
using System.Collections.Generic;
using SportsTrainingManager.Models;

namespace SportsTrainingManager.Services
{
    /// <summary>
    /// UserService.cs - Manages user profile updates, validation, and display formatting
    ///
    /// WHAT IT DOES:
    /// - Updates the current user's profile information
    /// - Validates email addresses and phone numbers
    /// - Formats profile summaries and dashboard info for display
    /// - Provides readable labels for experience levels and roles
    /// - Recommends the next step based on profile completion
    ///
    /// DEPENDS ON:
    /// - AuthenticationService - to get and update the current logged in user
    ///
    /// TIME COMPLEXITY:
    /// - UpdateCurrentUserProfile: O(1) - simple property assignments
    /// - GetProfileSummary:        O(1) - string formatting only
    /// - IsValidEmail:             O(1) - single validation check
    /// - IsValidPhoneNumber:       O(n) - regex scans the phone string
    ///
    /// SPACE COMPLEXITY: O(1) for all operations
    /// </summary>
    public class UserService
    {
        // ═══════════════════════════════════════════════════
        // FIELDS
        // ═══════════════════════════════════════════════════

        // Reference to the authentication service so we can get and update the current user
        private AuthenticationService _authService;

        // ═══════════════════════════════════════════════════
        // CONSTRUCTOR
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Creates a new UserService with a reference to the authentication service
        /// The auth service is required - we cannot manage users without it
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public UserService(AuthenticationService authService)
        {
            // Store the auth service reference so we can use it in our methods
            _authService = authService;
        }

        // ═══════════════════════════════════════════════════
        // PROFILE MANAGEMENT
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Updates the current logged in user's profile with new information
        /// Returns true if update was successful, false if no user is logged in
        ///
        /// TIME COMPLEXITY: O(1) - simple property assignments
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public bool UpdateCurrentUserProfile(
            string fullName,    // new full name for the user
            string email,       // new email address
            string phoneNumber, // new phone number (optional)
            string sport,       // new sport selection
            string targetArea,  // new target training area
            int experience)     // new experience level (1, 2, or 3)
        {
            // Get the currently logged in user from the auth service
            var user = _authService.GetCurrentUser();

            // If no user is logged in we cannot update anything
            if (user == null)
                return false; // no user logged in - return false

            // Update each profile field with the new values
            user.FullName = fullName;           // update the display name
            user.Email = email;                 // update the email address
            user.PhoneNumber = phoneNumber;     // update the phone number
            user.Sport = sport;                 // update the selected sport
            user.TargetArea = targetArea;       // update the training focus area
            user.ExperienceLevel = experience;  // update the experience level

            // Save the updated user back through the auth service
            // Return true if save was successful, false if it failed
            return _authService.UpdateUserProfile(user);
        }

        // ═══════════════════════════════════════════════════
        // DISPLAY / FORMATTING METHODS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Builds a formatted profile summary string for the given user
        /// Returns a readable multi-line summary with all profile details
        /// Returns "User not found" if a null user is passed in
        ///
        /// TIME COMPLEXITY: O(1) - string formatting only
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetProfileSummary(User user)
        {
            // If no user was passed in return a safe fallback message
            if (user == null)
                return "User not found";

            // Build and return the formatted profile summary
            string summary = $@"
╔════════════════════════════════════════════════════════════════╗
║                      USER PROFILE SUMMARY                      ║
╚════════════════════════════════════════════════════════════════╝

Name:    {user.FullName}
Role:    {GetRoleLabel(user.Role)}
Email:   {user.Email}
Phone:   {user.PhoneNumber ?? "Not provided"}

Sport:        {user.Sport}
Target Area:  {user.TargetArea}
Experience:   {GetExperienceLabel(user.ExperienceLevel)}

Account Created: {user.DateCreated:MMM dd, yyyy}
Last Login:      {user.LastLogin:MMM dd, yyyy HH:mm}
Status:          {(user.IsActive ? "Active" : "Inactive")}

════════════════════════════════════════════════════════════════";

            return summary;
        }

        /// <summary>
        /// Builds a formatted dashboard summary string for the given user
        /// Includes key stats like active goals, sessions logged, and progress
        ///
        /// TIME COMPLEXITY: O(1) - string formatting only
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetDashboardInfo(
            User user,              // the athlete whose dashboard we are building
            int activeGoals,        // how many goals are currently active
            int totalSessions,      // how many training sessions have been logged
            double averageProgress, // overall average progress percentage
            int upcomingEvents)     // how many events are coming up this week
        {
            // If no user was passed in return a safe fallback message
            if (user == null)
                return "User not found";

            // Build and return the formatted dashboard summary
            string dashboard = $@"
╔════════════════════════════════════════════════════════════════╗
║               {user.FullName.ToUpper()}'s DASHBOARD                    ║
╚════════════════════════════════════════════════════════════════╝

Sport: {user.Sport} | Target: {user.TargetArea}

STATS:
  Active Goals:             {activeGoals}
  Training Sessions Logged: {totalSessions}
  Overall Progress:         {averageProgress:F1}%
  Upcoming Events:          {upcomingEvents}

════════════════════════════════════════════════════════════════";

            return dashboard;
        }

        // ═══════════════════════════════════════════════════
        // LABEL HELPERS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Converts the experience level number to a readable label
        /// 1 = Beginner, 2 = Intermediate, 3 = Advanced
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetExperienceLabel(int level)
        {
            // Use switch expression to return the correct label
            return level switch
            {
                1 => "Beginner",      // just starting out
                2 => "Intermediate",  // some experience
                3 => "Advanced",      // competitive level
                _ => "Unknown"        // catch any invalid values
            };
        }

        /// <summary>
        /// Converts the UserRole enum to a readable label
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetRoleLabel(UserRole role)
        {
            // Use switch expression to return the correct label
            return role switch
            {
                UserRole.Parent => "Parent / Guardian",  // managing a young athlete
                UserRole.Coach => "Coach / Trainer",    // providing guidance
                UserRole.Athlete => "Athlete",            // training to improve
                _ => "Unknown"             // catch any invalid values
            };
        }

        // ═══════════════════════════════════════════════════
        // VALIDATION METHODS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Validates that an email address is in a proper format
        /// Uses the built in MailAddress class to check the format
        /// Returns true if valid, false if not
        ///
        /// EXAMPLE:
        /// - "bobby@gmail.com"  → true
        /// - "notanemail"       → false
        /// - "missing@domain"   → false
        ///
        /// TIME COMPLEXITY: O(1) - single validation check
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public bool IsValidEmail(string email)
        {
            // If email is empty or null it is not valid
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Try to create a MailAddress object - this validates the format
                var addr = new System.Net.Mail.MailAddress(email);

                // Make sure the parsed address matches the original input exactly
                return addr.Address == email;
            }
            catch
            {
                // If MailAddress threw an exception the format is invalid
                return false;
            }
        }

        /// <summary>
        /// Validates that a phone number has at least 10 digits
        /// Phone number is optional so empty or null returns true
        /// Strips all non-digit characters before counting
        ///
        /// EXAMPLE:
        /// - null or ""         → true (phone is optional)
        /// - "(312) 555-1234"   → true (10 digits after stripping)
        /// - "555-1234"         → false (only 7 digits)
        ///
        /// TIME COMPLEXITY: O(n) where n = length of phone string (regex scan)
        /// SPACE COMPLEXITY: O(n) for the cleaned string
        /// </summary>
        public bool IsValidPhoneNumber(string phone)
        {
            // Phone number is optional so empty or null is considered valid
            if (string.IsNullOrWhiteSpace(phone))
                return true;

            // Remove all non-digit characters (spaces, dashes, parentheses, etc.)
            // Example: "(312) 555-1234" becomes "3125551234"
            var cleaned = System.Text.RegularExpressions.Regex.Replace(phone, @"[^\d]", "");

            // A valid US phone number needs at least 10 digits
            return cleaned.Length >= 10;
        }

        // ═══════════════════════════════════════════════════
        // RECOMMENDATION METHODS
        // ═══════════════════════════════════════════════════

        /// <summary>
        /// Returns a recommended next step based on how complete the user's profile is
        /// Helps guide new users through the setup process
        ///
        /// TIME COMPLEXITY: O(1)
        /// SPACE COMPLEXITY: O(1)
        /// </summary>
        public string GetRecommendedNextStep(User user)
        {
            // If no user was passed in return a safe fallback message
            if (user == null)
                return "Please log in to continue";

            // Check if sport has been selected yet
            if (string.IsNullOrWhiteSpace(user.Sport))
                return "Complete your sport selection to get started";

            // Check if target area has been selected yet
            if (string.IsNullOrWhiteSpace(user.TargetArea))
                return "Choose your target training area";

            // Profile is complete - recommend creating a goal
            return "Create a goal and generate your first training session";
        }
    }
}